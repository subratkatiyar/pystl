def min(f, s):
    return f if f < s else s